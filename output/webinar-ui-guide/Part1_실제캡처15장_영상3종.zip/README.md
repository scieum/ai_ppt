# Part 1 실제 인앱 조작 기록

2026-10-27. 사용자 요청으로 실제 Codex·Claude 데스크톱에서 제작·수정했다. 원본 JPEG 15개는 재생성·합성하지 않았으며 SHA-256·화면 크기·앱 정보는 `captures.json`에 있다. PPT의 확대 영역은 원본 이미지를 유지한 PowerPoint 크롭이다.

## 환경과 결과

| 항목 | Codex | Claude |
|---|---|---|
| 실제 환경 | Windows 인앱, GPT-6.1 Sol Medium | Windows Desktop 3.6556.2.0, Opus 5.5 높음 |
| 첫 결과 | 10초 MP4 | 10초 HTML 아티팩트 |
| 시간 수정 | 11초 MP4 | 같은 HTML 아티팩트 11초 |
| 개인화 | 가운데 질문 교체, 전체 11초 MP4 | 이번 실행에서는 개인화 요청 미실행 |
| 저장 | `results/`의 MP4 3개 | 실제 아티팩트 재생 캡처. 로컬 HTML·MP4 내보내기 완료는 미확인 |

이 계정에서 관찰한 결과이며 모든 버전·요금제의 동일 동작을 보장하지 않는다. Codex 첫 요청·시간 수정은 사용자가 허용한 실습용 새 채팅 도구로 전달했다. 실제 입력창 입력·제출은 개인화 요청에서 캡처했다. 수동으로 입력한 첫 프롬프트 화면을 촬영했다고 표시하지 않는다. Claude는 새 대화 입력창에서 직접 입력·제출했다.

## 사용한 프롬프트

첫 요청 — 두 앱 동일:

> 수업을 시작할 때 보여 줄 10초짜리 글자 영상을 만들어 줘. ‘오늘의 질문’, ‘왜 그렇게 생각했나요?’, ‘근거 한 가지’를 차례로 보여 줘. 검정 바탕에 주황색으로 강조하고 재생할 수 있는 미리보기로 보여 줘.

시간 수정 — 두 앱 동일:

> ‘왜 그렇게 생각했나요?’가 머무는 시간만 1초 늘려 줘. 문구·등장 순서·색상·나머지 동작은 그대로 유지해 줘. 전체 길이는 1초 늘어나도 괜찮아.

개인화 — Codex 실제 실행:

> 가운데 질문만 ‘두 그림에서 달라진 점은?’으로 바꿔 줘. 나머지 문구·순서·색·움직임은 유지해 줘.

## 보조 장표와 원본 대응

PPT는 코덱스 6장 다음 클로드 6장이다. 단계 하나당 실제 조작 영역을 확대하고 별도 설명을 붙였다. 아래 순서는 강의용 배열이며 캡처 시각의 시간순 배열과 구분한다.

| PPT 장 | 조작 | 원본 캡처 |
|---:|---|---|
| 1 | Codex 첫 요청 전달 | `codex/01-prompt-submitted.jpg` |
| 2 | 첫 MP4 재생 | `codex/03-first-result-playing.jpg` |
| 3 | 시간 수정 요청 | `codex/04-revision-submitted.jpg` |
| 4 | 질문 장면·11초 확인 | `codex/06-revised-question-seek.jpg` |
| 5 | 개인화 요청 입력 | `codex/07-personalization-entered.jpg` |
| 6 | 개인화 결과 확인 | `codex/09-personalized-result.jpg` |
| 7 | Claude 첫 요청 입력 | `claude/01-prompt-entered.jpg` |
| 8 | 실제 생성 중 상태 | `claude/02-generating.jpg` |
| 9 | 첫 HTML 아티팩트 | `claude/03-first-artifact.jpg` |
| 10 | 시간 수정 요청 입력 | `claude/05-revision-entered.jpg` |
| 11 | 11초 아티팩트 재생 | `claude/07-revised-question-playing.jpg` |
| 12 | 내보내기 메뉴 위치 | `claude/04-export-menu.jpg` |

보조 장표와 별개로 수정 전후 재생·요청 제출 직후 등의 원본도 보관했다. 대화·아티팩트는 비공개 계정 문서이며 공개 링크를 생성하지 않았다. 전체 제작 게이트·사람의 디자인 검토·G10 권리 검토는 완료한 것으로 표시하지 않는다. 교육 배포 전 앱 UI·표식·글꼴 등 실제 사용 범위를 G10 목록에 등록한다.

OpenAI의 일반 브라우저 안내는 [공식 문서](https://learn.chatgpt.com/docs/browser?surface=app)를 참고할 수 있다. 이번 PPT는 일반 문서의 UI 재현이 아니라 위에서 관찰한 실제 앱 화면을 사용한다.
